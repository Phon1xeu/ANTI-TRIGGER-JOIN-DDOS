Config = {}

Config.WebhookLogging = true
Config.WebhookURL = 'https://discord.com/api/webhooks/TVUJ-WEBHOOK'

-- Join spam
Config.ConnectionThreshold = 10
Config.ConnectionWindow = 10 -- sekund

-- Trigger flood
Config.LogTriggers = true
Config.TriggerLimit = 20
Config.TriggerWindow = 10

-- Lag detection
Config.LagDetection = true
Config.MaxTickTime = 250
Config.TickCheckInterval = 5000

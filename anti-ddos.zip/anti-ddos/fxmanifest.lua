fx_version 'cerulean'
game 'gta5'

author 'Phon1x'
description 'ANTI-TRIGGER/JOIN DDOS, CLASSIC DDOS LOGING'
version '1.0.0'

server_scripts {
    'config.lua',
    'server.lua'
}

local connectionSpam = {}
local triggerSpam = {}

function logToConsole(message)
    print("^3[ANTI-DDOS]^0 " .. message)
end

function logToWebhook(title, description)
    if not Config.WebhookLogging then return end

    local embed = {{
        ["title"] = title,
        ["description"] = description,
        ["color"] = 16711680,
        ["footer"] = {
            ["text"] = "Anti-DDoS System • " .. os.date("%Y-%m-%d %H:%M:%S")
        }
    }}

    PerformHttpRequest(Config.WebhookURL, function(err, text, headers) end, "POST", json.encode({
        username = "Anti-DDoS Logger",
        embeds = embed
    }), { ["Content-Type"] = "application/json" })
end


AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
    local ip = GetPlayerEndpoint(source)
    local time = os.time()

    if connectionSpam[ip] then
        if time - connectionSpam[ip].last <= Config.ConnectionWindow then
            connectionSpam[ip].count = connectionSpam[ip].count + 1
        else
            connectionSpam[ip].count = 1
        end
        connectionSpam[ip].last = time

        if connectionSpam[ip].count >= Config.ConnectionThreshold then
            logToConsole("Blocked connection spam from IP: " .. ip)
            logToWebhook("Connection Flood Detected", "Blocked join spam from IP: `" .. ip .. "`\nPlayer: `" .. name .. "`")
            CancelEvent()
            return
        end
    else
        connectionSpam[ip] = { count = 1, last = time }
    end
end)


RegisterServerEvent("ddos:triggerTest")
AddEventHandler("ddos:triggerTest", function()
    local src = source
    local time = os.time()

    if not triggerSpam[src] then
        triggerSpam[src] = { count = 1, last = time }
    else
        if time - triggerSpam[src].last <= Config.TriggerWindow then
            triggerSpam[src].count = triggerSpam[src].count + 1
        else
            triggerSpam[src].count = 1
        end
        triggerSpam[src].last = time

        if triggerSpam[src].count >= Config.TriggerLimit then
            logToConsole("Trigger flood detected from player: " .. GetPlayerName(src))
            logToWebhook("Trigger Flood", "Player: `" .. GetPlayerName(src) .. "`\nTrigger: `ddos:triggerTest`\nFlood Count: `" .. triggerSpam[src].count .. "`")
            DropPlayer(src, "[Anti-DDoS] Trigger flood detected.")
        end
    end
end)


if Config.LagDetection then
    CreateThread(function()
        while true do
            Wait(Config.TickCheckInterval)
            local tickTime = GetHostTickTime() * 1000

            if tickTime > Config.MaxTickTime then
                local msg = ("Server tick time too high: %.1f ms (limit: %d ms)"):format(tickTime, Config.MaxTickTime)
                logToConsole(msg)
                logToWebhook("Potential Server Lag / DDoS", msg .. "\nPlayers Online: " .. #GetPlayers())
            end
        end
    end)
end
